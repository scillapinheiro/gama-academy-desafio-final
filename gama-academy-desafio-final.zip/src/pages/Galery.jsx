import React from 'react';
import '../styles/Galery.css'

export function Galery() {
    return (
        <>
            <div>
                    <p>Galery</p>
            </div>
        </>
    );
}

export default Galery;