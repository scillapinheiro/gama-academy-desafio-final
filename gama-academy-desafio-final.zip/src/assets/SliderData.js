
import foto1 from '../assets/slide1.jpg'
import foto2 from '../assets/slide2.jpg'
import foto3 from '../assets/slide3.jpg'
import foto4 from '../assets/slide4.jpg'

export const SliderData = [
    {
        image: foto1
    },
    {
        image: foto2
    },
    {
        image: foto3
    },
    {
        image: foto4
    },
];
